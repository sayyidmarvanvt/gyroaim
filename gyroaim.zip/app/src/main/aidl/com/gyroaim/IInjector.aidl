package com.gyroaim;

interface IInjector {
    void destroy() = 16777114;
    oneway void touch(int action, float x, float y) = 1;
    String shell(String cmd) = 2;
}
