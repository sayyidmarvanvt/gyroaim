package com.gyroaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.MotionEvent
import rikka.shizuku.Shizuku
import kotlin.math.abs
import kotlin.math.hypot

class AimService : Service(), SensorEventListener {
    companion object {
        @Volatile
        var running = false
    }

    private var inj: IInjector? = null
    private lateinit var sm: SensorManager
    private lateinit var p: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var sensing = false
    private var curPkg: String? = null
    private var lastQ = 0L

    private var last = 0L
    private var lastMove = 0L
    private var ox = 0f
    private var oy = 0f
    private var cx = 0f
    private var cy = 0f
    private var down = false
    private var paused = false
    private var sens = 900f
    private var rad = 300f
    private var invX = false
    private var invY = false
    private var pcx = 75
    private var pcy = 50

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, InjectorService::class.java.name))
            .processNameSuffix("injector")
            .daemon(false)
            .version(1)
    }

    private val poll = object : Runnable {
        override fun run() {
            checkForeground()
            handler.postDelayed(this, 600)
        }
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            val i = IInjector.Stub.asInterface(b)
            inj = i
            Thread {
                try {
                    i.shell("cmd appops set $packageName GET_USAGE_STATS allow")
                } catch (e: Exception) {
                }
            }.start()
            handler.post(poll)
        }

        override fun onServiceDisconnected(n: ComponentName) {
            inj = null
            stopSense()
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        p = getSharedPreferences("s", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif())
        }
        Shizuku.bindUserService(args, conn)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "TOGGLE" -> {
                paused = !paused
                if (paused) stopSense()
                getSystemService(NotificationManager::class.java).notify(1, notif())
            }
            "STOP" -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun checkForeground() {
        try {
            val usm = getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            val from = if (lastQ == 0L) now - 6 * 3600_000L else lastQ - 2000
            val ev = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                when (e.eventType) {
                    1 -> curPkg = e.packageName
                    2 -> if (e.packageName == curPkg) curPkg = null
                }
            }
            lastQ = now
        } catch (e: Exception) {
        }
        val sel = p.getStringSet("apps", emptySet()) ?: emptySet()
        val want = !paused && curPkg != null && sel.contains(curPkg)
        if (want && !sensing) startSense() else if (!want && sensing) stopSense()
    }

    private fun startSense() {
        reload()
        last = 0L
        val g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        sm.registerListener(this, g, 5000)
        sensing = true
    }

    private fun stopSense() {
        if (sensing) {
            sm.unregisterListener(this)
            sensing = false
        }
        lift()
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("aim", "Gyro aim", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String) = PendingIntent.getService(
            this, a.hashCode(), Intent(this, AimService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val ic = Icon.createWithResource(this, R.drawable.ic_stat)
        return Notification.Builder(this, "aim")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(if (paused) "GyroAim paused" else "GyroAim ready")
            .setContentText("Aims automatically in your chosen games")
            .addAction(Notification.Action.Builder(ic, if (paused) "Resume" else "Pause", pi("TOGGLE")).build())
            .addAction(Notification.Action.Builder(ic, "Stop", pi("STOP")).build())
            .build()
    }

    private fun reload() {
        val k = curPkg ?: return
        sens = Cfg.int(p, k, "sens").toFloat()
        rad = Cfg.int(p, k, "rad").toFloat()
        pcx = Cfg.int(p, k, "cx")
        pcy = Cfg.int(p, k, "cy")
        invX = Cfg.bool(p, k, "invx")
        invY = Cfg.bool(p, k, "invy")
    }

    private fun center() {
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(0).getRealMetrics(dm)
        cx = dm.widthPixels * pcx / 100f
        cy = dm.heightPixels * pcy / 100f
    }

    private fun t(a: Int, x: Float, y: Float) {
        try {
            inj?.touch(a, x, y)
        } catch (e: Exception) {
        }
    }

    private fun lift() {
        if (down) {
            t(MotionEvent.ACTION_UP, cx + ox, cy + oy)
            down = false
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (paused) return
        val now = e.timestamp
        val dt = (now - last) / 1e9f
        last = now
        if (dt <= 0f || dt > 0.1f) return

        val gx = e.values[0]
        val gy = e.values[1]
        if (abs(gx) + abs(gy) < 0.03f) {
            if (down && now - lastMove > 300_000_000L) lift()
            return
        }
        lastMove = now

        if (!down) {
            reload(); center(); ox = 0f; oy = 0f
            t(MotionEvent.ACTION_DOWN, cx, cy)
            down = true
        }
        ox += (if (invX) -gx else gx) * dt * sens
        oy += (if (invY) -gy else gy) * dt * sens

        if (hypot(ox, oy) > rad) {
            t(MotionEvent.ACTION_UP, cx + ox, cy + oy)
            ox = 0f; oy = 0f
            t(MotionEvent.ACTION_DOWN, cx, cy)
        } else {
            t(MotionEvent.ACTION_MOVE, cx + ox, cy + oy)
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(poll)
        stopSense()
        try {
            Shizuku.unbindUserService(args, conn, true)
        } catch (t: Throwable) {
        }
        super.onDestroy()
    }
}
