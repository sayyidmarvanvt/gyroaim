package com.gyroaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.MotionEvent
import rikka.shizuku.Shizuku
import kotlin.math.abs
import kotlin.math.hypot

class AimService : Service(), SensorEventListener {
    private var inj: IInjector? = null
    private lateinit var sm: SensorManager
    private lateinit var p: SharedPreferences

    private var last = 0L
    private var lastMove = 0L
    private var ox = 0f
    private var oy = 0f
    private var cx = 0f
    private var cy = 0f
    private var down = false
    private var paused = false
    private var sens = 900f
    private var rad = 300f
    private var invX = false
    private var invY = false

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, InjectorService::class.java.name))
            .processNameSuffix("injector")
            .daemon(false)
            .version(1)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            inj = IInjector.Stub.asInterface(b)
            reload()
            val g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            sm.registerListener(this@AimService, g, 5000)
        }

        override fun onServiceDisconnected(n: ComponentName) {
            inj = null
        }
    }

    override fun onCreate() {
        super.onCreate()
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        p = getSharedPreferences("s", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif())
        }
        Shizuku.bindUserService(args, conn)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "TOGGLE" -> {
                paused = !paused
                if (paused) lift()
                getSystemService(NotificationManager::class.java).notify(1, notif())
            }
            "STOP" -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("aim", "Gyro aim", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String) = PendingIntent.getService(
            this, a.hashCode(), Intent(this, AimService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val ic = Icon.createWithResource(this, android.R.drawable.ic_menu_compass)
        return Notification.Builder(this, "aim")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(if (paused) "Gyro aim PAUSED" else "Gyro aim ACTIVE")
            .addAction(Notification.Action.Builder(ic, if (paused) "Resume" else "Pause", pi("TOGGLE")).build())
            .addAction(Notification.Action.Builder(ic, "Stop", pi("STOP")).build())
            .build()
    }

    private fun reload() {
        sens = p.getInt("sens", 900).toFloat()
        rad = p.getInt("rad", 300).toFloat()
        invX = p.getBoolean("invx", false)
        invY = p.getBoolean("invy", false)
    }

    private fun center() {
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(0).getRealMetrics(dm)
        cx = dm.widthPixels * p.getInt("cx", 75) / 100f
        cy = dm.heightPixels * p.getInt("cy", 50) / 100f
    }

    private fun t(a: Int, x: Float, y: Float) {
        try {
            inj?.touch(a, x, y)
        } catch (e: Exception) {
        }
    }

    private fun lift() {
        if (down) {
            t(MotionEvent.ACTION_UP, cx + ox, cy + oy)
            down = false
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (paused) return
        val now = e.timestamp
        val dt = (now - last) / 1e9f
        last = now
        if (dt <= 0f || dt > 0.1f) return

        val gx = e.values[0]
        val gy = e.values[1]
        if (abs(gx) + abs(gy) < 0.03f) {
            if (down && now - lastMove > 300_000_000L) lift()
            return
        }
        lastMove = now

        if (!down) {
            reload(); center(); ox = 0f; oy = 0f
            t(MotionEvent.ACTION_DOWN, cx, cy)
            down = true
        }
        ox += (if (invX) -gx else gx) * dt * sens
        oy += (if (invY) -gy else gy) * dt * sens

        if (hypot(ox, oy) > rad) {
            t(MotionEvent.ACTION_UP, cx + ox, cy + oy)
            ox = 0f; oy = 0f
            t(MotionEvent.ACTION_DOWN, cx, cy)
        } else {
            t(MotionEvent.ACTION_MOVE, cx + ox, cy + oy)
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        sm.unregisterListener(this)
        lift()
        try {
            Shizuku.unbindUserService(args, conn, true)
        } catch (t: Throwable) {
        }
        super.onDestroy()
    }
}
