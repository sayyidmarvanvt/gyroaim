package com.gyroaim

import android.content.SharedPreferences

// Per-game settings, stored as "key:packageName".
object Cfg {
    const val SENS_MIN = 50
    const val SENS_MAX = 5000
    val defaults = mapOf("sens" to 900, "cx" to 75, "cy" to 50, "rad" to 300)

    fun int(p: SharedPreferences, pkg: String, k: String): Int = p.getInt(k + ":" + pkg, defaults[k] ?: 0)

    fun putInt(p: SharedPreferences, pkg: String, k: String, v: Int) {
        p.edit().putInt(k + ":" + pkg, v).apply()
    }

    fun bool(p: SharedPreferences, pkg: String, k: String): Boolean = p.getBoolean(k + ":" + pkg, false)

    fun putBool(p: SharedPreferences, pkg: String, k: String, v: Boolean) {
        p.edit().putBoolean(k + ":" + pkg, v).apply()
    }

    fun reset(p: SharedPreferences, pkg: String) {
        val e = p.edit()
        for (k in listOf("sens", "cx", "cy", "rad", "invx", "invy")) e.remove(k + ":" + pkg)
        e.apply()
    }
}
