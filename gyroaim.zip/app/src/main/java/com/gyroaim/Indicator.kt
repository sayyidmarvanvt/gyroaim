package com.gyroaim

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager

// Click-through overlay that shows the look-area ring and the invisible finger.
class Indicator(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var v: IView? = null

    fun show() {
        if (v != null) return
        val view = IView(ctx)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.LEFT
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (android.os.Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(view, lp)
            v = view
        } catch (e: Exception) {
        }
    }

    fun hide() {
        val x = v ?: return
        try {
            wm.removeView(x)
        } catch (e: Exception) {
        }
        v = null
    }

    fun update(cx: Float, cy: Float, rad: Float, x: Float, y: Float, down: Boolean) {
        v?.set(cx, cy, rad, x, y, down)
    }

    class IView(c: Context) : View(c) {
        private var rx = 0f
        private var ry = 0f
        private var rr = 0f
        private var dx = 0f
        private var dy = 0f
        private var dn = false
        private var lastInv = 0L
        private val loc = IntArray(2)
        private val d = c.resources.displayMetrics.density
        private val ringP = Paint(Paint.ANTI_ALIAS_FLAG)
        private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG)

        init {
            ringP.style = Paint.Style.STROKE
            ringP.strokeWidth = 2 * d
            ringP.color = Color.parseColor("#99E5534B")
            dotP.color = Color.parseColor("#E5534B")
            edgeP.style = Paint.Style.STROKE
            edgeP.strokeWidth = 2 * d
            edgeP.color = Color.WHITE
        }

        fun set(cx: Float, cy: Float, rad: Float, x: Float, y: Float, down: Boolean) {
            rx = cx; ry = cy; rr = rad; dx = x; dy = y
            val changed = down != dn
            dn = down
            val now = SystemClock.uptimeMillis()
            if (changed || now - lastInv > 30) {
                lastInv = now
                invalidate()
            }
        }

        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            val ox = loc[0].toFloat()
            val oy = loc[1].toFloat()
            if (rr > 0f) c.drawCircle(rx - ox, ry - oy, rr, ringP)
            if (dn) {
                c.drawCircle(dx - ox, dy - oy, 11 * d, dotP)
                c.drawCircle(dx - ox, dy - oy, 11 * d, edgeP)
            }
        }
    }
}
