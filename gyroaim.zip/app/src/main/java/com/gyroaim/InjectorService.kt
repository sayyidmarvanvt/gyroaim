package com.gyroaim

import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.lang.reflect.Method
import kotlin.system.exitProcess

// Runs inside the Shizuku (shell-privileged) process.
class InjectorService : IInjector.Stub() {
    private val im: Any
    private val inject: Method
    private var downTime = 0L

    init {
        val c = Class.forName("android.hardware.input.InputManager")
        im = c.getDeclaredMethod("getInstance").invoke(null)!!
        inject = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
    }

    override fun destroy() {
        exitProcess(0)
    }

    override fun touch(action: Int, x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) downTime = now
        val e = MotionEvent.obtain(downTime, now, action, x, y, 1f, 1f, 0, 1f, 1f, -1, 0)
        e.source = InputDevice.SOURCE_TOUCHSCREEN
        try {
            inject.invoke(im, e, 0)
        } catch (t: Throwable) {
            Log.e("GyroAim", "inject failed", t)
        }
        e.recycle()
    }
}
