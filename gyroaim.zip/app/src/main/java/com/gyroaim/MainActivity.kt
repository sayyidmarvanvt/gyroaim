package com.gyroaim

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var status: TextView
    private lateinit var sub: TextView
    private lateinit var toggle: Button
    private lateinit var games: TextView
    private lateinit var usageNote: TextView
    private lateinit var tuneCard: LinearLayout
    private var savedTv: TextView? = null

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) launch()
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = Ui.text(this, t, size, color, bold)
    private fun button(t: String, color: Int, click: () -> Unit) = Ui.button(this, t, color, click)

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l.topMargin = dp(top)
        return l
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Ui.round(this, Ui.CARD, 18)
        c.setPadding(dp(18), dp(16), dp(18), dp(18))
        return c
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("s", MODE_PRIVATE)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(32), dp(18), dp(32))
        root.addView(text("GyroAim", 30f, Color.WHITE, true))
        root.addView(text("Gyro aiming for touch games", 14f, Ui.MUTED))

        // Status card
        val c1 = card()
        status = text("", 20f, Color.WHITE, true)
        sub = text("", 13f, Ui.MUTED)
        toggle = button("Start", Ui.ACCENT) { toggleService() }
        c1.addView(status)
        c1.addView(sub, lp(4))
        c1.addView(toggle, lp(16))
        usageNote = text("Usage access not granted yet. It is set automatically once aiming starts. Tap here to open settings instead.", 12f, Ui.MUTED)
        usageNote.setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        c1.addView(usageNote, lp(12))
        root.addView(c1, lp(22))

        // Games card
        val c2 = card()
        c2.addView(text("Games", 16f, Color.WHITE, true))
        games = text("", 14f, Ui.MUTED)
        c2.addView(games, lp(4))
        c2.addView(button("Choose games", Ui.DARK) { pickGames() }, lp(14))
        root.addView(c2, lp(14))

        // Tuning card (rebuilt for the selected game)
        tuneCard = card()
        root.addView(tuneCard, lp(14))

        root.addView(text("Tip: play in landscape. Use Pause in the notification while you are in menus.", 12f, Ui.MUTED), lp(16))

        val sv = ScrollView(this)
        sv.setBackgroundColor(Ui.BG)
        sv.addView(root)
        setContentView(sv)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    private fun selected(): Set<String> = p.getStringSet("apps", emptySet()) ?: emptySet()

    private fun hasUsage(): Boolean {
        val ao = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun tuneTarget(): String? {
        val sel = selected()
        if (sel.isEmpty()) return null
        val saved = p.getString("tune_pkg", null)
        if (saved != null && sel.contains(saved)) return saved
        return sel.sortedBy { appName(it).lowercase() }.first()
    }

    private fun refresh() {
        val on = AimService.running
        val sel = selected()
        status.text = if (on) "Active" else "Stopped"
        status.setTextColor(if (on) Ui.GREEN else Color.WHITE)
        sub.text = if (on) "Aiming turns on by itself when a chosen game is open."
        else "Press Start once. You do not need to reopen this app."
        toggle.text = if (on) "Stop" else "Start"
        toggle.background = Ui.round(this, if (on) Ui.RED else Ui.ACCENT, 14)
        games.text = if (sel.isEmpty()) "No game chosen yet" else sel.joinToString(", ") { appName(it) }
        usageNote.visibility = if (hasUsage()) View.GONE else View.VISIBLE
        buildTuning()
    }

    private fun postRefresh() {
        window.decorView.postDelayed({ refresh() }, 500)
    }

    private fun flashSaved() {
        val v = savedTv ?: return
        v.text = "Saved \u2713"
        v.animate().cancel()
        v.alpha = 1f
        v.animate().alpha(0f).setStartDelay(1200).setDuration(400).start()
    }

    private fun buildTuning() {
        tuneCard.removeAllViews()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(text("Tuning", 16f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sv = text("", 12f, Ui.GREEN)
        sv.alpha = 0f
        savedTv = sv
        head.addView(sv)
        tuneCard.addView(head)

        val pkg = tuneTarget()
        if (pkg == null) {
            tuneCard.addView(text("Choose a game above and its settings appear here. Every game keeps its own settings.", 13f, Ui.MUTED), lp(8))
            return
        }

        tuneCard.addView(button("Game: " + appName(pkg) + "  (change)", Ui.DARK) { chooseTuneGame() }, lp(12))

        tuneCard.addView(button("Edit look area on the game", Ui.ACCENT) { editArea(pkg) }, lp(10))

        tuneCard.addView(text("Sensitivity (type a number, 50 to 5000)", 14f, Color.WHITE), lp(16))
        tuneCard.addView(Ui.sensRow(this, p, pkg) { flashSaved() }, lp(6))

        slider(tuneCard, pkg, "Look area: left/right (%)", "cx", 5, 95)
        slider(tuneCard, pkg, "Look area: up/down (%)", "cy", 5, 95)
        slider(tuneCard, pkg, "Look area size (px)", "rad", 100, 600)
        check(tuneCard, pkg, "Invert horizontal", "invx")
        check(tuneCard, pkg, "Invert vertical", "invy")

        val dot = CheckBox(this)
        dot.text = "Show the finger dot while playing"
        dot.setTextColor(Color.WHITE)
        dot.isChecked = p.getBoolean("showdot", false)
        dot.buttonTintList = ColorStateList.valueOf(Ui.ACCENT)
        dot.setOnCheckedChangeListener { _, c ->
            p.edit().putBoolean("showdot", c).apply()
            flashSaved()
        }
        tuneCard.addView(dot, lp(8))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val test = button("Test pad", Ui.ACCENT) {
            startActivity(Intent(this, TestActivity::class.java).putExtra("pkg", pkg))
        }
        val reset = button("Reset this game", Ui.RED) {
            Cfg.reset(p, pkg)
            Toast.makeText(this, "Reset to defaults", Toast.LENGTH_SHORT).show()
            buildTuning()
        }
        val l1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l1.rightMargin = dp(6)
        val l2 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l2.leftMargin = dp(6)
        row.addView(test, l1)
        row.addView(reset, l2)
        tuneCard.addView(row, lp(18))
    }

    private fun editArea(pkg: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Appear on top\" for GyroAim, then come back and tap again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            Toast.makeText(this, "Cannot open that game", Toast.LENGTH_SHORT).show()
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java).putExtra("pkg", pkg))
        startActivity(launch)
    }

    private fun chooseTuneGame() {
        val sel = selected().toList().sortedBy { appName(it).lowercase() }
        val names = sel.map { appName(it) }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Tune which game?")
            .setItems(names) { _, i ->
                p.edit().putString("tune_pkg", sel[i]).apply()
                buildTuning()
            }
            .show()
    }

    private fun toggleService() {
        if (AimService.running) {
            stopService(Intent(this, AimService::class.java))
            postRefresh()
            return
        }
        if (selected().isEmpty()) {
            Toast.makeText(this, "Choose a game first", Toast.LENGTH_SHORT).show()
            pickGames()
            return
        }
        if (!Shizuku.pingBinder()) {
            status.text = "Shizuku is not running"
            sub.text = "Start Shizuku first (Wireless debugging), then press Start again."
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(100)
            return
        }
        launch()
    }

    private fun launch() {
        startForegroundService(Intent(this, AimService::class.java))
        postRefresh()
    }

    private fun pickGames() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { Triple(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.second.lowercase() }
        val sel = selected().toMutableSet()

        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(pos: Int): Any = apps[pos]
            override fun getItemId(pos: Int) = pos.toLong()
            override fun getView(pos: Int, cv: View?, parent: ViewGroup?): View {
                val (pkg, label, icon) = apps[pos]
                val row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(8), dp(8), dp(8), dp(8))
                val iv = ImageView(this@MainActivity)
                iv.setImageDrawable(icon as Drawable)
                row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
                val tv = text(label, 16f, Color.WHITE)
                val l = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                l.leftMargin = dp(12)
                row.addView(tv, l)
                val cb = CheckBox(this@MainActivity)
                cb.isChecked = sel.contains(pkg)
                cb.isClickable = false
                cb.isFocusable = false
                cb.buttonTintList = ColorStateList.valueOf(Ui.ACCENT)
                row.addView(cb)
                return row
            }
        }
        val lv = ListView(this)
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            if (!sel.remove(pkg)) sel.add(pkg)
            p.edit().putStringSet("apps", HashSet(sel)).apply()
            adapter.notifyDataSetChanged()
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Choose games")
            .setView(lv)
            .setPositiveButton("Done") { _, _ -> refresh() }
            .setOnDismissListener { refresh() }
            .show()
    }

    private fun slider(parent: LinearLayout, pkg: String, label: String, key: String, min: Int, max: Int) {
        val v = Cfg.int(p, pkg, key)
        val tv = text("$label: $v", 14f, Color.WHITE)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (v - min).coerceIn(0, max - min)
        sb.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, pr: Int, u: Boolean) {
                Cfg.putInt(p, pkg, key, pr + min)
                tv.text = "$label: ${pr + min}"
                if (u) flashSaved()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        parent.addView(tv, lp(16))
        parent.addView(sb, lp(2))
    }

    private fun check(parent: LinearLayout, pkg: String, label: String, key: String) {
        val cb = CheckBox(this)
        cb.text = label
        cb.setTextColor(Color.WHITE)
        cb.isChecked = Cfg.bool(p, pkg, key)
        cb.buttonTintList = ColorStateList.valueOf(Ui.ACCENT)
        cb.setOnCheckedChangeListener { _, c ->
            Cfg.putBool(p, pkg, key, c)
            flashSaved()
        }
        parent.addView(cb, lp(8))
    }
}
