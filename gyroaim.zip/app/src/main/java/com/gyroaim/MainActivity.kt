package com.gyroaim

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var status: TextView

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) launch()
        else status.text = "Shizuku permission denied."
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("s", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 60, 40, 40)

        status = TextView(this)
        status.text = "1) Start Shizuku  2) Press Start  3) Open your game (landscape)"
        root.addView(status)

        slider(root, "Sensitivity", "sens", 100, 3000, 900)
        slider(root, "Aim centre X (% of width)", "cx", 5, 95, 75)
        slider(root, "Aim centre Y (% of height)", "cy", 5, 95, 50)
        slider(root, "Aim radius (px)", "rad", 100, 600, 300)
        check(root, "Invert horizontal", "invx")
        check(root, "Invert vertical", "invy")

        val start = Button(this)
        start.text = "Start aiming"
        start.setOnClickListener { onStart() }
        root.addView(start)

        val stop = Button(this)
        stop.text = "Stop"
        stop.setOnClickListener { stopService(Intent(this, AimService::class.java)) }
        root.addView(stop)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    private fun onStart() {
        if (!Shizuku.pingBinder()) {
            status.text = "Shizuku is not running. Start it first."
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(100)
            return
        }
        launch()
    }

    private fun launch() {
        startForegroundService(Intent(this, AimService::class.java))
        status.text = "Running. Switch to your game. Use the notification to pause."
    }

    private fun slider(root: LinearLayout, label: String, key: String, min: Int, max: Int, def: Int) {
        val v = p.getInt(key, def)
        val tv = TextView(this)
        tv.text = "$label: $v"
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = v - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, pr: Int, u: Boolean) {
                p.edit().putInt(key, pr + min).apply()
                tv.text = "$label: ${pr + min}"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        root.addView(tv)
        root.addView(sb)
    }

    private fun check(root: LinearLayout, label: String, key: String) {
        val cb = CheckBox(this)
        cb.text = label
        cb.isChecked = p.getBoolean(key, false)
        cb.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply() }
        root.addView(cb)
    }
}
