package com.gyroaim

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var status: TextView
    private lateinit var sub: TextView
    private lateinit var toggle: Button
    private lateinit var games: TextView
    private lateinit var usageNote: TextView

    private val cBg = Color.parseColor("#0E1116")
    private val cCard = Color.parseColor("#171B23")
    private val cAccent = Color.parseColor("#4F8CFF")
    private val cGreen = Color.parseColor("#35C46A")
    private val cRed = Color.parseColor("#E5534B")
    private val cMuted = Color.parseColor("#8A93A3")

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) launch()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l.topMargin = dp(top)
        return l
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = bg(cCard, 18)
        c.setPadding(dp(18), dp(16), dp(18), dp(18))
        return c
    }

    private fun button(t: String, color: Int, click: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.background = bg(color, 14)
        b.setOnClickListener { click() }
        return b
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("s", MODE_PRIVATE)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(32), dp(18), dp(32))
        root.addView(text("GyroAim", 30f, Color.WHITE, true))
        root.addView(text("Gyro aiming for touch games", 14f, cMuted))

        // Status card
        val c1 = card()
        status = text("", 20f, Color.WHITE, true)
        sub = text("", 13f, cMuted)
        toggle = button("Start", cAccent) { toggleService() }
        c1.addView(status)
        c1.addView(sub, lp(4))
        c1.addView(toggle, lp(16))
        usageNote = text("Usage access not granted yet. It is set automatically once aiming starts. Tap here to open settings instead.", 12f, cMuted)
        usageNote.setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        c1.addView(usageNote, lp(12))
        root.addView(c1, lp(22))

        // Games card
        val c2 = card()
        c2.addView(text("Games", 16f, Color.WHITE, true))
        games = text("", 14f, cMuted)
        c2.addView(games, lp(4))
        c2.addView(button("Choose games", Color.parseColor("#262C38")) { pickGames() }, lp(14))
        root.addView(c2, lp(14))

        // Tuning card
        val c3 = card()
        c3.addView(text("Tuning", 16f, Color.WHITE, true))
        slider(c3, "Sensitivity", "sens", 100, 3000, 900)
        slider(c3, "Look area: left/right (%)", "cx", 5, 95, 75)
        slider(c3, "Look area: up/down (%)", "cy", 5, 95, 50)
        slider(c3, "Look area size (px)", "rad", 100, 600, 300)
        check(c3, "Invert horizontal", "invx")
        check(c3, "Invert vertical", "invy")
        root.addView(c3, lp(14))

        root.addView(text("Tip: play in landscape. Use Pause in the notification while you are in menus.", 12f, cMuted), lp(16))

        val sv = ScrollView(this)
        sv.setBackgroundColor(cBg)
        sv.addView(root)
        setContentView(sv)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    private fun selected(): Set<String> = p.getStringSet("apps", emptySet()) ?: emptySet()

    private fun hasUsage(): Boolean {
        val ao = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun refresh() {
        val on = AimService.running
        val sel = selected()
        status.text = if (on) "Active" else "Stopped"
        status.setTextColor(if (on) cGreen else Color.WHITE)
        sub.text = if (on) "Aiming turns on by itself when a chosen game is open."
        else "Press Start once. You do not need to reopen this app."
        toggle.text = if (on) "Stop" else "Start"
        toggle.background = bg(if (on) cRed else cAccent, 14)
        games.text = if (sel.isEmpty()) "No game chosen yet" else sel.joinToString(", ") { appName(it) }
        usageNote.visibility = if (hasUsage()) View.GONE else View.VISIBLE
    }

    private fun postRefresh() {
        window.decorView.postDelayed({ refresh() }, 500)
    }

    private fun toggleService() {
        if (AimService.running) {
            stopService(Intent(this, AimService::class.java))
            postRefresh()
            return
        }
        if (selected().isEmpty()) {
            Toast.makeText(this, "Choose a game first", Toast.LENGTH_SHORT).show()
            pickGames()
            return
        }
        if (!Shizuku.pingBinder()) {
            status.text = "Shizuku is not running"
            sub.text = "Start Shizuku first (Wireless debugging), then press Start again."
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(100)
            return
        }
        launch()
    }

    private fun launch() {
        startForegroundService(Intent(this, AimService::class.java))
        postRefresh()
    }

    private fun pickGames() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { Triple(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.second.lowercase() }
        val sel = selected().toMutableSet()

        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(pos: Int): Any = apps[pos]
            override fun getItemId(pos: Int) = pos.toLong()
            override fun getView(pos: Int, cv: View?, parent: ViewGroup?): View {
                val (pkg, label, icon) = apps[pos]
                val row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(8), dp(8), dp(8), dp(8))
                val iv = ImageView(this@MainActivity)
                iv.setImageDrawable(icon as Drawable)
                row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
                val tv = text(label, 16f, Color.WHITE)
                val l = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                l.leftMargin = dp(12)
                row.addView(tv, l)
                val cb = CheckBox(this@MainActivity)
                cb.isChecked = sel.contains(pkg)
                cb.isClickable = false
                cb.isFocusable = false
                cb.buttonTintList = ColorStateList.valueOf(cAccent)
                row.addView(cb)
                return row
            }
        }
        val lv = ListView(this)
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            if (!sel.remove(pkg)) sel.add(pkg)
            p.edit().putStringSet("apps", HashSet(sel)).apply()
            adapter.notifyDataSetChanged()
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Choose games")
            .setView(lv)
            .setPositiveButton("Done") { _, _ -> refresh() }
            .setOnDismissListener { refresh() }
            .show()
    }

    private fun slider(parent: LinearLayout, label: String, key: String, min: Int, max: Int, def: Int) {
        val v = p.getInt(key, def)
        val tv = text("$label: $v", 14f, Color.WHITE)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = v - min
        sb.progressTintList = ColorStateList.valueOf(cAccent)
        sb.thumbTintList = ColorStateList.valueOf(cAccent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, pr: Int, u: Boolean) {
                p.edit().putInt(key, pr + min).apply()
                tv.text = "$label: ${pr + min}"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        parent.addView(tv, lp(16))
        parent.addView(sb, lp(2))
    }

    private fun check(parent: LinearLayout, label: String, key: String) {
        val cb = CheckBox(this)
        cb.text = label
        cb.setTextColor(Color.WHITE)
        cb.isChecked = p.getBoolean(key, false)
        cb.buttonTintList = ColorStateList.valueOf(cAccent)
        cb.setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply() }
        parent.addView(cb, lp(8))
    }
}
