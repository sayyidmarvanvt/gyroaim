package com.gyroaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var root: View? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val pkg = i?.getStringExtra("pkg")
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("aim", "Gyro aim", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "aim")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("GyroAim: editing look area")
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }
        if (pkg == null || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        removeEditor()
        showEditor(pkg)
        return START_NOT_STICKY
    }

    private fun showEditor(pkg: String) {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        val ed = EditorView(this, pkg, label)
        val frame = FrameLayout(this)
        frame.addView(ed, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val cancel = Ui.button(this, "Cancel", Ui.DARK) { stopSelf() }
        val reset = Ui.button(this, "Reset", Ui.DARK) { ed.resetDefaults() }
        val save = Ui.button(this, "Save", Ui.ACCENT) {
            ed.save()
            Toast.makeText(this, "Saved for $label", Toast.LENGTH_SHORT).show()
            stopSelf()
        }
        for (b in listOf(cancel, reset, save)) {
            val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 48))
            l.leftMargin = Ui.dp(this, 6)
            l.rightMargin = Ui.dp(this, 6)
            bar.addView(b, l)
        }
        val bl = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        bl.bottomMargin = Ui.dp(this, 16)
        frame.addView(bar, bl)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.LEFT
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        AimService.editing = true
        w.addView(frame, lp)
        root = frame
    }

    private fun removeEditor() {
        val r = root ?: return
        try {
            wm?.removeView(r)
        } catch (e: Exception) {
        }
        root = null
    }

    override fun onDestroy() {
        removeEditor()
        AimService.editing = false
        super.onDestroy()
    }
}

class EditorView(private val c: Context, private val pkg: String, private val label: String) : View(c) {
    private val p = c.getSharedPreferences("s", Context.MODE_PRIVATE)
    private val d = c.resources.displayMetrics.density
    private val loc = IntArray(2)
    private var cx = 0f
    private var cy = 0f
    private var r = 300f
    private var moved = false
    private var mode = 0
    private var lx = 0f
    private var ly = 0f

    private val red = Color.parseColor("#E5534B")
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val whiteP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txtP = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        fillP.color = Color.argb(70, 229, 83, 75)
        strokeP.style = Paint.Style.STROKE
        strokeP.strokeWidth = 3 * d
        strokeP.color = red
        whiteP.color = Color.WHITE
        txtP.color = Color.WHITE
        txtP.textSize = 14 * d
        txtP.textAlign = Paint.Align.CENTER
        txtP.setShadowLayer(4 * d, 0f, 0f, Color.BLACK)
    }

    private fun real(): DisplayMetrics {
        val dm = DisplayMetrics()
        (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(0).getRealMetrics(dm)
        return dm
    }

    private fun place() {
        getLocationOnScreen(loc)
        val dm = real()
        cx = dm.widthPixels * Cfg.int(p, pkg, "cx") / 100f - loc[0]
        cy = dm.heightPixels * Cfg.int(p, pkg, "cy") / 100f - loc[1]
        r = Cfg.int(p, pkg, "rad").toFloat()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (!moved) place()
    }

    fun resetDefaults() {
        cx = 0f
        moved = false
        val dm = real()
        getLocationOnScreen(loc)
        cx = dm.widthPixels * (Cfg.defaults["cx"] ?: 75) / 100f - loc[0]
        cy = dm.heightPixels * (Cfg.defaults["cy"] ?: 50) / 100f - loc[1]
        r = (Cfg.defaults["rad"] ?: 300).toFloat()
        moved = true
        invalidate()
    }

    fun save() {
        getLocationOnScreen(loc)
        val dm = real()
        val px = (cx + loc[0]) / dm.widthPixels * 100f
        val py = (cy + loc[1]) / dm.heightPixels * 100f
        Cfg.putInt(p, pkg, "cx", px.roundToInt().coerceIn(5, 95))
        Cfg.putInt(p, pkg, "cy", py.roundToInt().coerceIn(5, 95))
        Cfg.putInt(p, pkg, "rad", r.roundToInt().coerceIn(100, 600))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val dist = hypot(e.x - cx, e.y - cy)
                val edge = minOf(44 * d, r * 0.3f)
                mode = if (abs(dist - r) < edge) 2 else if (dist < r) 1 else 0
                lx = e.x
                ly = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 1) {
                    cx += e.x - lx
                    cy += e.y - ly
                    moved = true
                } else if (mode == 2) {
                    r = hypot(e.x - cx, e.y - cy).coerceIn(100f, 600f)
                    moved = true
                }
                lx = e.x
                ly = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        cv.drawColor(Color.argb(90, 0, 0, 0))
        cv.drawCircle(cx, cy, r, fillP)
        cv.drawCircle(cx, cy, r, strokeP)
        cv.drawLine(cx - 14 * d, cy, cx + 14 * d, cy, strokeP)
        cv.drawLine(cx, cy - 14 * d, cx, cy + 14 * d, strokeP)
        cv.drawCircle(cx + r, cy, 11 * d, whiteP)

        getLocationOnScreen(loc)
        val dm = real()
        val px = ((cx + loc[0]) / dm.widthPixels * 100f).roundToInt()
        val py = ((cy + loc[1]) / dm.heightPixels * 100f).roundToInt()
        val mid = width / 2f
        cv.drawText("Look area for $label", mid, 34 * d, txtP)
        cv.drawText("Drag the red circle onto EMPTY space (no buttons). Drag the white dot to resize.", mid, 56 * d, txtP)
        cv.drawText("Left/right $px%   Up/down $py%   Size ${r.roundToInt()} px", mid, 78 * d, txtP)
    }
}
