package com.gyroaim

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.hypot

class TestActivity : Activity(), SensorEventListener {
    private lateinit var p: SharedPreferences
    private lateinit var pkg: String
    private lateinit var pad: PadView
    private lateinit var sm: SensorManager
    private lateinit var fh: Button
    private lateinit var fv: Button

    private var sens = 900f
    private var rad = 300f
    private var invX = false
    private var invY = false
    private var last = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        p = getSharedPreferences("s", MODE_PRIVATE)
        val k = intent.getStringExtra("pkg")
        if (k == null) {
            finish()
            return
        }
        pkg = k
        sm = getSystemService(SENSOR_SERVICE) as SensorManager

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        pad = PadView(this)
        root.addView(pad, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.CARD)
        bar.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8))

        bar.addView(Ui.text(this, "Sens", 14f, Color.WHITE))
        val sr = Ui.sensRow(this, p, pkg) { loadCfg() }
        val srLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        srLp.leftMargin = Ui.dp(this, 10)
        bar.addView(sr, srLp)

        fh = Ui.button(this, "", Ui.DARK) {
            Cfg.putBool(p, pkg, "invx", !Cfg.bool(p, pkg, "invx"))
            loadCfg()
        }
        fv = Ui.button(this, "", Ui.DARK) {
            Cfg.putBool(p, pkg, "invy", !Cfg.bool(p, pkg, "invy"))
            loadCfg()
        }
        val close = Ui.button(this, "Close", Ui.ACCENT) { finish() }
        for (b2 in listOf(fh, fv, close)) {
            val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 46))
            l.leftMargin = Ui.dp(this, 10)
            bar.addView(b2, l)
        }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        loadCfg()
    }

    private fun loadCfg() {
        sens = Cfg.int(p, pkg, "sens").toFloat()
        rad = Cfg.int(p, pkg, "rad").toFloat()
        invX = Cfg.bool(p, pkg, "invx")
        invY = Cfg.bool(p, pkg, "invy")
        pad.rad = rad
        fh.text = "Flip H: " + (if (invX) "on" else "off")
        fv.text = "Flip V: " + (if (invY) "on" else "off")
        pad.invalidate()
    }

    override fun onResume() {
        super.onResume()
        last = 0L
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE), 5000)
    }

    override fun onPause() {
        sm.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val now = e.timestamp
        val dt = (now - last) / 1e9f
        last = now
        if (dt <= 0f || dt > 0.1f) return
        val gx = e.values[0]
        val gy = e.values[1]
        if (abs(gx) + abs(gy) < 0.03f) return
        pad.ox += (if (invX) -gx else gx) * dt * sens
        pad.oy += (if (invY) -gy else gy) * dt * sens
        if (hypot(pad.ox, pad.oy) > rad) {
            pad.ox = 0f
            pad.oy = 0f
            pad.flash = 6
            pad.clearTrail()
        }
        pad.push()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

class PadView(ctx: Context) : View(ctx) {
    var rad = 300f
    var ox = 0f
    var oy = 0f
    var flash = 0
    private val trail = ArrayList<FloatArray>()
    private val d = ctx.resources.displayMetrics.density
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trailP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linesP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txtP = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        ringP.style = Paint.Style.STROKE
        ringP.strokeWidth = 3 * d
        trailP.style = Paint.Style.STROKE
        trailP.strokeWidth = 4 * d
        trailP.strokeCap = Paint.Cap.ROUND
        trailP.color = Ui.ACCENT
        dotP.color = Color.WHITE
        linesP.color = Color.parseColor("#2A3040")
        linesP.strokeWidth = 1 * d
        txtP.color = Ui.MUTED
        txtP.textSize = 13 * d
        txtP.textAlign = Paint.Align.CENTER
    }

    fun push() {
        trail.add(floatArrayOf(ox, oy))
        if (trail.size > 90) trail.removeAt(0)
        invalidate()
    }

    fun clearTrail() {
        trail.clear()
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Ui.BG)
        val w = width.toFloat()
        val h = height.toFloat()
        val mx = w / 2f
        val my = h / 2f
        val ringR = minOf(rad, minOf(w, h) / 2f - 28 * d)
        val s = ringR / rad
        c.drawLine(mx, 0f, mx, h, linesP)
        c.drawLine(0f, my, w, my, linesP)
        ringP.color = if (flash > 0) Ui.GREEN else Ui.ACCENT
        c.drawCircle(mx, my, ringR, ringP)
        for (i in 1 until trail.size) {
            trailP.alpha = 255 * i / trail.size
            val a = trail[i - 1]
            val b = trail[i]
            c.drawLine(mx + a[0] * s, my + a[1] * s, mx + b[0] * s, my + b[1] * s, trailP)
        }
        c.drawCircle(mx + ox * s, my + oy * s, 12 * d, dotP)
        c.drawText("Tilt your phone. The white dot is the invisible finger.", mx, 28 * d, txtP)
        c.drawText("At the ring it jumps back to the centre.", mx, 48 * d, txtP)
        if (flash > 0) {
            flash--
            postInvalidateDelayed(30)
        }
    }
}
