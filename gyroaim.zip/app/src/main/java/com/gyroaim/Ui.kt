package com.gyroaim

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val BG = Color.parseColor("#0E1116")
    val CARD = Color.parseColor("#171B23")
    val ACCENT = Color.parseColor("#4F8CFF")
    val GREEN = Color.parseColor("#35C46A")
    val RED = Color.parseColor("#E5534B")
    val MUTED = Color.parseColor("#8A93A3")
    val DARK = Color.parseColor("#262C38")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun round(c: Context, color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, r).toFloat()
        return g
    }

    fun text(c: Context, t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(c)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    fun button(c: Context, t: String, color: Int, click: () -> Unit): Button {
        val b = Button(c)
        b.text = t
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.background = round(c, color, 14)
        b.setOnClickListener { click() }
        return b
    }

    // "-  [ number ]  +" row that edits the sensitivity of one game.
    fun sensRow(c: Context, p: SharedPreferences, pkg: String, onChange: () -> Unit): LinearLayout {
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val et = EditText(c)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.imeOptions = EditorInfo.IME_ACTION_DONE
        et.setSingleLine(true)
        et.gravity = Gravity.CENTER
        et.setTextColor(Color.WHITE)
        et.setText(Cfg.int(p, pkg, "sens").toString())
        et.background = round(c, DARK, 12)

        fun cur(): Int = et.text.toString().toIntOrNull() ?: Cfg.int(p, pkg, "sens")
        fun commit(v: Int) {
            val n = v.coerceIn(Cfg.SENS_MIN, Cfg.SENS_MAX)
            Cfg.putInt(p, pkg, "sens", n)
            et.setText(n.toString())
            et.setSelection(et.text.length)
            onChange()
        }

        val minus = button(c, "-", DARK) { commit(cur() - 50) }
        val plus = button(c, "+", DARK) { commit(cur() + 50) }
        for (b in listOf(minus, plus)) {
            b.minWidth = 0
            b.minimumWidth = 0
            b.minHeight = 0
            b.minimumHeight = 0
        }

        et.setOnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) {
                commit(cur())
                v.clearFocus()
            }
            false
        }
        et.setOnFocusChangeListener { _, has ->
            if (!has && et.text.toString().toIntOrNull() != Cfg.int(p, pkg, "sens")) commit(cur())
        }

        row.addView(minus, LinearLayout.LayoutParams(dp(c, 52), dp(c, 46)))
        val lp = LinearLayout.LayoutParams(dp(c, 100), dp(c, 46))
        lp.leftMargin = dp(c, 8)
        lp.rightMargin = dp(c, 8)
        row.addView(et, lp)
        row.addView(plus, LinearLayout.LayoutParams(dp(c, 52), dp(c, 46)))
        return row
    }
}
